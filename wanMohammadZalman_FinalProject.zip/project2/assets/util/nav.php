	<div class="bordering">
		<h1>TOURING EUROPE</h1>
		<div class="navlistTOP">
			<ul>
				<li><a href="<?=URL?>index.php">Home</a></li>
				<li><a href="<?=URL?>pages/uk.php">England</a></li>
				<li><a href="<?=URL?>pages/france.php">France</a></li>
				<li><a href="<?=URL?>pages/bnh.php">Belgium & Holland</a></li>
				<li><a href="<?=URL?>pages/gna.php">Germany & Austria</a></li>
				<li><a href="<?=URL?>pages/swiss.php">Switzerland</a></li>
				<li><a href="<?=URL?>pages/italy.php">Italy</a>
					<ul>
						<li><a href="<?=URL?>pages/pisa.php">Pisa</a></li>
						<li><a href="<?=URL?>pages/rome.php">Rome</a></li>
						<li><a href="<?=URL?>pages/venice.php">Venice</a></li>
					</ul>
				</li>
				<li><a href="<?=URL?>pages/about.php">About</a></li>
				<li><a href="<?=URL?>pages/comments.php">Comments</a></li>
			</ul>
		</div>
	</div>